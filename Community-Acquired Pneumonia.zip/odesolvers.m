% close all the figures when the script runs
close all, clear, clc

%% Simulation 1

% parameters and initial conditions
alpha = 0.9;
beta = 0.001;
gamma = 0.3;
mu = 0.001;
delta = 0.25;
eta = 0.05;

S0 = 800;
I0 = 1200;
R0 = 1004;
V0 = 1003;

% x-axis interval
x1 = 0;
x2 = 80;

% create the simulation based on inital conditions and parameters
params = [alpha beta gamma mu delta eta];
tspan = [x1 x2];
ICs = [S0 I0 R0 V0];
[t2, y2] = ode45(@(t, y) odefnc(t, y, params), tspan, ICs);

% get the basic reproduction number, and last values of each class
R_0_1 = (beta * y2(end,1) / (alpha + mu))
S_1_end = y2(end,1)
I_1_end = y2(end,2)
R_1_end = y2(end,3)
V_1_end = y2(end,4)

% plot of figure 1
f1 = figure(1);
plot(t2, y2, 'LineWidth', 2)
legend('S', 'I', 'R', 'V')
ylabel('Population')
xlabel('Time')
title('All classes stabilizing at E_0')
colororder(["#ED1B0C";"#0CAAED";"#E68000";"#02CF13"])
ylim([0 6000])

% plot of figure 2 - S, S^*
f2 = figure(2);
plot(t2, y2(:,1), 'Color','#ED1B0C', 'LineWidth', 2) 
yline(y2(end,1), "--", 'Color','#FAC907', 'LineWidth', 2)
legend('S', "S^*")
ylabel('Population')
xlabel('Time')
title('Susceptible class with stable E_0')

% plot of figure 3 - I, I^*
f3 = figure(3);
plot(t2, y2(:,2), 'Color','#ED1B0C', 'LineWidth', 2) 
yline(0, "--", 'Color','#FAC907', 'LineWidth', 2)
legend('I', "I^*")
ylabel('Population')
xlabel('Time')
title('Infected class with stable E_0')

% plot of figure 4 - R, equilibrium R^*
f4 = figure(4);
plot(t2, y2(:,3), 'Color','#ED1B0C', 'LineWidth', 2)
yline(0, "--", 'Color','#FAC907', 'LineWidth', 2)
legend('R', "R^*")
ylabel('Population')
xlabel('Time')
title('Recovered class with stable E_0')

% plot of figure 5 - V, V^*
f5 = figure(5);
plot(t2, y2(:,4), 'LineWidth', 2, 'Color', '#ED1B0C')
yline(y2(end,1) * (delta / eta), "--", 'Color', '#FAC907', 'LineWidth', 2)
legend('V', "V^*")
ylabel('Population')
xlabel('Time')
title('Vaccinated class with stable E_0')
ylim([0 5000])

% plot of figure 6 - S, S^*
f6 = figure(6);
plot(t2, y2(:,1), 'Color','#ED1B0C', 'LineWidth', 2)
yline((alpha + mu) / beta, "--", 'Color','#FAC907', 'LineWidth', 2) 
legend('S', "S^*")
ylabel('Population')
xlabel('Time')
title('Susceptible class with unstable E^*')
ylim([0 1300])

% plot of figure 7 - I^*
f7 = figure(7);
plot(t2, y2(:,2), 'Color','#ED1B0C', 'LineWidth', 2) 
yline(y2(end,2), "--", 'Color','#FAC907', 'LineWidth', 2)
legend('I', "I^*")
ylabel('Population')
xlabel('Time')
title('Infected class with unstable E^*')

% plot of figure 8 - R, R^*
f8 = figure(8);
plot(t2, y2(:,3), 'LineWidth', 2, 'Color','#ED1B0C')
yline(y2(end,2) * ((alpha + mu) / gamma), '--', 'Color', '#FAC907', 'LineWidth', 2);
legend('R', "R^*")
ylabel('Population')
xlabel('Time')
title('Recovered class with unstable E^*')
colororder(["#ED1B0C";"#FAC907";])

% plot of figure 9 - V, V^*
f9 = figure(9);
plot(t2, y2(:,4), 'Color','#ED1B0C', 'LineWidth', 2)
yline(((alpha + mu) / beta) * (delta / eta), "--", 'Color','#FAC907', 'LineWidth', 2)
legend('V', "V^*")
ylabel('Population')
xlabel('Time')
title('Vaccinated class with unstable E^*')
ylim([0 7000])

%% Simulation 2

% parameters and initial conditions
alpha = 0.01;
beta = 0.9;
gamma = 0.6;
mu = 0.00000001;
delta = 0.2;
eta = 0.1;

S0 = 2000;
I0 = 2000;
R0 = 150;
V0 = 3000;
        
% x-axis interval
x1 = 0;
x2 = 100;

% create the simulation based on inital conditions and parameters
params = [alpha beta gamma mu delta eta];
tspan = [x1 x2];
ICs = [S0 I0 R0 V0];
[t2, y2] = ode45(@(t, y) odefnc(t, y, params), tspan, ICs);

% get the basic reproduction number, and last values of each class
R_0_2 = (beta * y2(end,1) / (alpha + mu))
S_2_end = y2(end,1)
I_2_end = y2(end,2)
R_2_end = y2(end,3)
V_2_end = y2(end,4)

% plot of figure 10
f10 = figure(10);
plot(t2, y2, 'LineWidth', 2)
legend('S', 'I', 'R', 'V')
ylabel('Population')
xlabel('Time')
title('All classes stabilizing at E^*')
colororder(["#ED1B0C";"#0CAAED";"#E68000";"#02CF13"])
ylim([0 12000])

% plot of figure 11 - S, S^*
f11 = figure(11);
plot(t2, y2(:,1), 'Color','#ED1B0C', 'LineWidth', 2) 
yline(y2(end,1), "--", 'Color','#FAC907', 'LineWidth', 2)
legend('S', "S^*")
ylabel('Population')
xlabel('Time')
title('Susceptible class with unstable E_0')
xlim([0 0.003])

% plot of figure 12 - I, I^*
f12 = figure(12);
plot(t2, y2(:,2), 'Color','#ED1B0C', 'LineWidth', 2) 
yline(0, "--", 'Color','#FAC907', 'LineWidth', 2)
legend('I', "I^*")
ylabel('Population')
xlabel('Time')
title('Infected class with unstable E_0')
ylim([0 10000])

% plot of figure 13 - R, equilibrium R^*
f13 = figure(13);
plot(t2, y2(:,3), 'Color','#ED1B0C', 'LineWidth', 2)
yline(0, "--", 'Color','#FAC907', 'LineWidth', 2)
legend('R', "R^*")
ylabel('Population')
xlabel('Time')
title('Recovered class with unstable E_0')
ylim([0 200])

% plot of figure 14 - V, V^*
f14 = figure(14);
plot(t2, y2(:,4), 'LineWidth', 2, 'Color', '#ED1B0C')
yline(y2(end,1) * (delta / eta), "--", 'Color', '#FAC907', 'LineWidth', 2)
legend('V', "V^*")
ylabel('Population')
xlabel('Time')
title('Vaccinated class with unstable E_0')

% plot of figure 15 - S, S^*
f15 = figure(15);
plot(t2, y2(:,1), 'Color','#ED1B0C', 'LineWidth', 2)
yline((alpha + mu) / beta, "--", 'Color','#FAC907', 'LineWidth', 2) 
legend('S', "S^*")
ylabel('Population')
xlabel('Time')
title('Susceptible class with stable E^*')
xlim([0 0.003])

% plot of figure 16 - I^*
f16 = figure(16);
plot(t2, y2(:,2), 'Color','#ED1B0C', 'LineWidth', 2) 
yline(y2(end,2), "--", 'Color','#FAC907', 'LineWidth', 2)
legend('I', "I^*")
ylabel('Population')
xlabel('Time')
title('Infected class with stable E^*')
ylim([0 10000])

% plot of figure 17 - R, R^*
f17 = figure(17);
plot(t2, y2(:,3), 'LineWidth', 2, 'Color','#ED1B0C')
yline(y2(end,2) * ((alpha + mu) / gamma), '--', 'Color', '#FAC907', 'LineWidth', 2);
legend('R', "R^*")
ylabel('Population')
xlabel('Time')
title('Recovered class with stable E^*')
colororder(["#ED1B0C";"#FAC907";])

% plot of figure 18 - V, V^*
f18 = figure(18);
plot(t2, y2(:,4), 'Color','#ED1B0C', 'LineWidth', 2)
yline(((alpha + mu) / beta) * (delta / eta), "--", 'Color','#FAC907', 'LineWidth', 2)
legend('V', "V^*")
ylabel('Population')
xlabel('Time')
title('Vaccinated class with stable E^*')

%% Save all the figures
saveas(f1, "SIRV1", "png")
saveas(f2, "S01", "png")
saveas(f3, "I01", "png")
saveas(f4, "R01", "png")
saveas(f5, "V01", "png")
saveas(f6, "S11", "png")
saveas(f7, "I11", "png")
saveas(f8, "R11", "png")
saveas(f9, "V11", "png")
saveas(f10, "SIRV2", "png")
saveas(f11, "S02", "png")
saveas(f12, "I02", "png")
saveas(f13, "R02", "png")
saveas(f14, "V02", "png")
saveas(f15, "S12", "png")
saveas(f16, "I12", "png")
saveas(f17, "R12", "png")
saveas(f18, "V12", "png")

%% Solve the system of ordinary differential equations
function dy = odefnc(t,y,params)
    alpha = params(1);
    beta = params(2);
    gamma = params(3);
    mu = params(4);
    delta = params(5);
    eta = params(6);

    % S = y(1), I = y(2), R = y(3), V = y(4)
    dy = zeros(4, 1);
    dy(1) = (-beta * y(1) * y(2)) - (delta * y(1)) + (eta * y(4)) + (gamma * y(3));
    dy(2) = (beta * y(1) * y(2)) - (alpha * y(2)) - (mu * y(2));
    dy(3) = (alpha * y(2)) - (gamma * y(3));
    dy(4) = (delta * y(1)) - (eta * y(4));
end